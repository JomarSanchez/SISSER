 <div class="container">
      <div class="row">
         <div class="full-box cover">
             <div class="containerCenter">
                 <p class="text-center error404"> <i class="zmdi zmdi-mood-bad zmdi-hc-5x"></i></p>
                 <h1 class="text-center tituloError"> ERROR 404 </h1>
             </div>
         </div>
         <div class="col-lg-offset-5 col-xs-offset-3">
             <div class="btnPage btnBajar">
                  <a href="<?php echo SERVERURL;?>">Volver Página Principal </a>
             </div>
         </div>
      </div>
 </div>