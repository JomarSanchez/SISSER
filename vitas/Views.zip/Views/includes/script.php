<script src="<?php echo SERVERURL;?>Views/js/jquery-3.1.1.min.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/sweetalert2.min.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/bootstrap.min.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/material.min.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/ripples.min.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/main.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/provincia.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/funciones.js"></script>
<script src="<?php echo SERVERURL;?>Views/js/calcularedad.js"></script>


